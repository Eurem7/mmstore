// Product Data from the Image
const products = [
    { id: 1, name: "Combs", category: "Instruments", price: 75, image: "images/combs.jpg" },
    { id: 2, name: "Hair Curlers", category: "Instruments", price: 300, image: "images/hair_curlers.jpg" },
    { id: 3, name: "Hair Sprays", category: "Articles", price: 75, image: "images/hair_sprays.jpg" },
    { id: 4, name: "Towels", category: "Articles", price: 75, image: "images/towels.jpg" },
    { id: 5, name: "Mirrors", category: "Interior", price: 200, image: "images/mirrors.jpg" },
    { id: 6, name: "Salon Chairs", category: "Interior", price: 1000, image: "images/salon_chairs.jpg" },
    { id: 7, name: "Lighting", category: "Energy", price: 500, image: "images/lighting.jpg" }
];

// Display Products
const productList = document.getElementById("product-list");

function displayProducts() {
    productList.innerHTML = ""; 
    products.forEach(product => {
        const productCard = document.createElement("div");
        productCard.classList.add("product-card");
        productCard.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>$${product.price.toFixed(2)}</p>
            <button class="add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
        `;
        productList.appendChild(productCard);
    });
}

// Filter Products by Category
function filterProducts() {
    const selectedCategory = document.getElementById("category-filter").value;
    productList.innerHTML = ""; 

    products
        .filter(product => selectedCategory === "all" || product.category === selectedCategory)
        .forEach(product => {
            const productCard = document.createElement("div");
            productCard.classList.add("product-card");
            productCard.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>$${product.price.toFixed(2)}</p>
                <button class="add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
            `;
            productList.appendChild(productCard);
        });
}

// Add Product to Cart
function addToCart(productId) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    
    const product = products.find(p => p.id === productId);
    
    if (!product) {
        console.error("Product not found!");
        return;
    }

    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += 1; 
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    console.log("Cart before saving:", cart);  // 🔍 Debugging line

    localStorage.setItem("cart", JSON.stringify(cart));

    console.log("Cart saved to localStorage:", localStorage.getItem("cart"));  // 🔍 Debugging line

    alert(`${product.name} added to cart!`);
}


// Load products on page load
document.addEventListener("DOMContentLoaded", displayProducts);
// 🟢 Search Products by Name
function searchProducts() {
    const searchTerm = document.getElementById("search-bar").value.toLowerCase();
    productList.innerHTML = "";

    products
        .filter(product => product.name.toLowerCase().includes(searchTerm))
        .forEach(product => {
            const productCard = document.createElement("div");
            productCard.classList.add("product-card");
            productCard.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>$${product.price.toFixed(2)}</p>
                <button class="add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
            `;
            productList.appendChild(productCard);
        });

    if (productList.innerHTML === "") {
        productList.innerHTML = "<p>No products found.</p>";
    }
}
