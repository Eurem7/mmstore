document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ MMstore is ready!");
});
