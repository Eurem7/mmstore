console.log("✅ MMstore Server is starting...");
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const mysql = require("mysql");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));
console.log("✅ Express initialized.");

// ✅ Database Connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root", // Change if needed
    password: "", // Your database password
    database: "mmstore_db" // New database for MMstore
});

db.connect(err => {
    if (err) {
        console.error("❌ Database connection failed:", err);
        process.exit(1); // Stop server if database fails
    } else {
        console.log("✅ Connected to MMstore database.");
    }
});


// ✅ Test API Route
app.get("/", (req, res) => {
    res.send("✅ MMstore Server is running...");
});

// 📩 **Contact Form API**
app.post("/api/contact", (req, res) => {
    console.log("📩 Received a contact request:", req.body); // Debugging

    const { name, email, message } = req.body;

    if (!name || !email || !message) {
        return res.status(400).json({ message: "❌ All fields are required!" });
    }

    const sql = "INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)";
    db.query(sql, [name, email, message], (err, result) => {
        if (err) {
            console.error("❌ Error saving contact message:", err);
            res.status(500).json({ message: "❌ Message sending failed!" });
        } else {
            res.json({ message: "✅ Message sent successfully!" });
        }
    });
});


// ✅ API to Save Booking
app.post("/api/bookings", (req, res) => {
    const { name, email, service, date, time } = req.body;

    if (!name || !email || !service || !date || !time) {
        return res.status(400).json({ message: "❌ All fields are required!" });
    }

    const sql = "INSERT INTO bookings (name, email, service, date, time) VALUES (?, ?, ?, ?, ?)";
    db.query(sql, [name, email, service, date, time], (err, result) => {
        if (err) {
            console.error("❌ Error saving booking:", err);
            res.status(500).json({ message: "❌ Booking failed!" });
        } else {
            res.json({ message: "✅ Booking successful!" });
        }
    });
});

// ✅ API to Retrieve All Bookings
app.get("/api/bookings", (req, res) => {
    const sql = "SELECT * FROM bookings ORDER BY date, time";
    db.query(sql, (err, results) => {
        if (err) {
            console.error("❌ Error fetching bookings:", err);
            res.status(500).json({ message: "Failed to fetch bookings" });
        } else {
            res.json(results);
        }
    });
});

// ✅ Start the Server
const PORT = 5000; // Different port to avoid conflicts
app.listen(PORT, () => {
    console.log(`🚀 MMstore Server running on http://localhost:${PORT}`);
});
